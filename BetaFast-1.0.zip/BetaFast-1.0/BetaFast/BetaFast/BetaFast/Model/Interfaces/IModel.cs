﻿namespace BetaFast.Model.Interfaces
{
    public interface IModel
    {
    }
}
