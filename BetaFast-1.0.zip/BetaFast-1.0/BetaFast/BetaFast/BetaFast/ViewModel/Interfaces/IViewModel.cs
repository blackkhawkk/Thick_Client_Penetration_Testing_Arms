﻿namespace BetaFast.ViewModel.Interfaces
{
    public interface IViewModel
    {
    }
}
