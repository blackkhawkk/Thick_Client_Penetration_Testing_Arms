﻿namespace BetaFast.ViewModel.Interfaces
{
    public interface IViewModelAuthenticated : IViewModel
    {
    }
}
