﻿using BetaFast.ViewModel.Base;

namespace BetaFast.ViewModel
{
    class AboutUsViewModel : ViewModelWithNavigationBarBase
    {
        public AboutUsViewModel()
        {
        }
    }
}
