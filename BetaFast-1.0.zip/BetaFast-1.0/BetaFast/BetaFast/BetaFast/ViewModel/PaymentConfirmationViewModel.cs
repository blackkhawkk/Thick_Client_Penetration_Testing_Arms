﻿using BetaFast.ViewModel.Base;

namespace BetaFast.ViewModel
{
    class PaymentConfirmationViewModel : ViewModelWithNavigationBarBase
    {
        public PaymentConfirmationViewModel()
        {
        }
    }
}
