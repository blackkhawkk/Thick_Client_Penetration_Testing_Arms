﻿namespace BetaFast.View.Interfaces
{
    public interface IMainView : IView
    {
        void Show();
    }
}
