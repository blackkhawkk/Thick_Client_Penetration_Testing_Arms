﻿using System.Windows.Controls;

namespace BetaFast.View
{
    /// <summary>
    /// Interaction logic for MovieManagementView.xaml
    /// </summary>
    public partial class MovieManagementView : UserControl
    {
        public MovieManagementView()
        {
            InitializeComponent();
        }
    }
}
