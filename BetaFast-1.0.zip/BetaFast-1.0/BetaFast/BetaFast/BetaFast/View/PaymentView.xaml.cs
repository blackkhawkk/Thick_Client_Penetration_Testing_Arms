﻿using System.Windows.Controls;

namespace BetaFast.View
{
    /// <summary>
    /// Interaction logic for PaymentView.xaml
    /// </summary>
    public partial class PaymentView : UserControl
    {
        public PaymentView()
        {
            InitializeComponent();
        }

        private void ExpiryDateBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
