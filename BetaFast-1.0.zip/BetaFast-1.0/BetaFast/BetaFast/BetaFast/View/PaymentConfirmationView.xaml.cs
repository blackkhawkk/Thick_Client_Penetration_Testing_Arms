﻿using System.Windows.Controls;

namespace BetaFast.View
{
    /// <summary>
    /// Interaction logic for ThankYouView.xaml
    /// </summary>
    public partial class PaymentConfirmationView : UserControl
    {
        public PaymentConfirmationView()
        {
            InitializeComponent();
        }
    }
}
