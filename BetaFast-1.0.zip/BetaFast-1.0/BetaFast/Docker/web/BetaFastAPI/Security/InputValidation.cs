using System.Text.RegularExpressions;

namespace BetaFastAPI.Security
{
    public static class InputValidation
    {
        public static bool IsValidFileName(string name)
        {
            return true;
        }
    }
}