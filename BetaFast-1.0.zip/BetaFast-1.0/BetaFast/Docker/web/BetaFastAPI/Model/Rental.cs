﻿namespace BetaFastAPI.Model
{
    public class Rental
    {
        public string Username { get; set; }
        public string Title { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }
    }
}
