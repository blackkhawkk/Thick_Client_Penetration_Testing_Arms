﻿namespace BetaBank.View.Interfaces
{
    public interface IMainView : IView
    {
        void Show();
    }
}