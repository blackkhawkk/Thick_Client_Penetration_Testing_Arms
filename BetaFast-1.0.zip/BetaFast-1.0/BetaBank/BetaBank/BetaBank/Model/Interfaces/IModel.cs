﻿namespace BetaBank.Model.Interfaces
{
    public interface IModel
    {
    }
}