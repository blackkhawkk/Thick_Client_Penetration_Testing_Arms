﻿namespace BetaBank.ViewModel.Interfaces
{
    public interface IViewModelAuthenticated : IViewModel
    {
    }
}