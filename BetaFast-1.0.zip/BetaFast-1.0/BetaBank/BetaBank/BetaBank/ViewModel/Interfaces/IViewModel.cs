﻿namespace BetaBank.ViewModel.Interfaces
{
    public interface IViewModel
    {
    }
}